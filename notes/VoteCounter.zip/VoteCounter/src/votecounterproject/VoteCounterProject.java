package votecounterproject;

/**
 * @version Spring 2019
 * @author clatulip
 */
public class VoteCounterProject {

    public static void main(String[] args) {
        
        //TODO Comment the following single statement out
        ArrayVoteCounter.runRandomElectionResults();
        
        //TODO Unomment the following single statement out
        //ArrayListVoteCounter.runRandomElectionResults();
    }

}